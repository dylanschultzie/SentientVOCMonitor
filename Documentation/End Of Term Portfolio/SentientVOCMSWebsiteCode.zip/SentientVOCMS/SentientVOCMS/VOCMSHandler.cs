﻿using System;
using System.Web;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace SentientVOCMS
{
    public partial class VOCMSHandler : System.Web.UI.Page
    {
        /// <summary>
        /// You will need to configure this handler in the Web.config file of your 
        /// web and register it with IIS before being able to use it. For more information
        /// see the following link: http://go.microsoft.com/?linkid=8101007 
        /// </summary>
        #region IHttpHandler Members

        //protected bool IsReusable
        //{
        //    // Return false in case your Managed Handler cannot be reused for another request.
        //    // Usually this would be false in case you have some state information preserved per request.
        //    get { return true; }
        //}

        //public void ProcessRequest(HttpContext context)
        //{
        //    //write your handler implementation here.
        //}

        #endregion

        protected void AlertSubmitButton_Click(object sender, EventArgs e)
        {
            string firstName = "";
            string lastName = "";
            string email = "";

            firstName = Request.Form["TextBox1"];
            lastName = Request.Form["TextBox2"];
            email = Request.Form["TextBox3"];

            SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["VOCMSConnectionString"].ConnectionString);
            SqlCommand cm = new SqlCommand();
            cm.Connection = cn;

            SqlParameter param1 = new SqlParameter("@FirstName", firstName);
            SqlParameter param2 = new SqlParameter("@LastName", lastName);
            SqlParameter param3 = new SqlParameter("@Email", email);

            param1.Size = firstName.Length;
            param2.Size = lastName.Length;
            param3.Size = email.Length;

            String insert = "INSERT INTO AlertSubscriber (FirstName, LastName, Email) VALUES (@FirstName, @LastName, @Email)";

            cm.CommandText = insert;
            cm.CommandType = CommandType.Text;
            cm.Parameters.Add(param1);
            cm.Parameters.Add(param2);
            cm.Parameters.Add(param3);



            cn.Open();
            cm.ExecuteReader();
            cn.Close();
        }
    }
}
